clc
clear all
close all


str = fileread('KDDTrain+.txt');
str = strrep( str, 'S0', '49' );
str = strrep( str, 'normal', 48 );

str = strrep( str, 'neptune',49 );
str = strrep( str, 'back',49 );
str = strrep( str, 'land',49 );
str = strrep( str, 'pod',49 );
str = strrep( str, 'smurf',49 );
str = strrep( str, 'teardrop',49 );
str = strrep( str, 'apache 2',49 );
str = strrep( str, 'udpstorm',49 );
str = strrep( str, 'processtable',49 );
str = strrep( str, 'worm',49 );

str = strrep( str, 'satan',50 );
str = strrep( str, 'ipsweep',50 );
str = strrep( str, 'nmap',50 );
str = strrep( str, 'portsweep',50 );
str = strrep( str, 'mscan',50 );
str = strrep( str, 'saint',50 );

str = strrep( str, 'guess_passwd',51 );
str = strrep( str, 'ftp_write',51 );
str = strrep( str, 'imap',51 );
str = strrep( str, 'phf',51 );
str = strrep( str, 'multihop',51 );
str = strrep( str, 'warezmaster',51 );
str = strrep( str, 'warezclient',51 );
str = strrep( str, 'spy',51 );
str = strrep( str, 'xlock',51 );
str = strrep( str, 'xsnoop',51 );
str = strrep( str, 'snmpguess',51 );
str = strrep( str, 'snmpgetattack',51 );
str = strrep( str, 'httptunnel',51 );
str = strrep( str, 'sendfmail',51 );
str = strrep( str, 'named',51 );

str = strrep( str, 'buffer_overflow',52 );
str = strrep( str, 'loadmodule',52 );
str = strrep( str, 'perl',52 );
str = strrep( str, 'rootkit',52 );
str = strrep( str, 'sqlattack',52 );
str = strrep( str, 'ps',52 );
str = strrep( str, 'tcp',48 );
str = strrep( str, 'udp',49 );
str = strrep( str, 'icmp',50 );
str = strrep( str, 'SF',48 );
str = strrep( str, 'REJ',50 );
str = strrep( str, 'RSTR',51 );
str = strrep( str, 'SH',52 );
str = strrep( str, 'RSTO',53 );
str = strrep( str, 'S1',54 );
str = strrep( str, 'RSTOS0',53 );
str = strrep( str, 'S3',55 );
str = strrep( str, 'S2',56 );
str = strrep( str, 'OTH',57 );

data =textscan(str, '%s','Delimiter','');

data = cat(1,data{:});
%data{55086,1}=[];
String_data = regexp(data,'([A-Z a-z  _ ]+)','match'); % Remove all numeric
Numeric_data = regexp(data,'([0.00000-9.99999 10-200000]+)','match'); % Remove all letters
for i=1:size(data,1)
    if size(Numeric_data{i,1},2)~=42 || size(String_data{i,1},2)~=1
        Numeric_data{i,1}=[];
        String_data{i,1}=[];
    end
    
end
emptyCells = cellfun('isempty', Numeric_data); 

Numeric_data(all(emptyCells,2),:) = [];

Numeric_data = cat(1,Numeric_data{:});
String_data = cat(1,String_data{:});
DATA=[Numeric_data(:,1:2) Numeric_data(:,4:end)];
training_data=cellfun(@str2num,DATA); 
%training_data=unique(training_data,'rows');
features=training_data(:,1:end-2);
train_class=training_data(:,end-1);
%save('features')
%save('train_class')
%train_feature=load('features');
train_feature=zscore(features);
%save('train_feature');
%label=load('class');
save('train_feature.mat', 'train_feature')
save('train_class.mat', 'train_class')