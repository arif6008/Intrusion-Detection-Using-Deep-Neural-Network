clc
close all
%clear all
tic
train_f=cell2mat(struct2cell(load('train_feature.mat')));
train_c=cell2mat(struct2cell(load('train_class.mat')));

%train_acc = libsvmtrain(y, x, '-q -v 5 -s 0 -t 3 -c 2.00000000');
%train_acc = train(train_c, sparse(train_f), '-s2 -v8');
model = train(train_c, sparse(train_f));
model.trainAcc = train(train_c, sparse(train_f), '-s2 -v8');

test_f=cell2mat(struct2cell(load('test_feature.mat')));
test_c=cell2mat(struct2cell(load('test_class.mat')));

predicted_label = predict(test_c, sparse(test_f), model);
predicted_label_train = predict(train_c, sparse(train_f), model.trainAcc);
toc